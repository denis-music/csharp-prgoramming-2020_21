﻿namespace DLWMS.WinForms.Helpers
{
    public class DLWMSdb
    {
        public static KonekcijaNaBazu Baza { get; set; } = new KonekcijaNaBazu();
    }
}
